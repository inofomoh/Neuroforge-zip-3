How to sell this engine.
Set your price. Offer license.
Distribute zip to users.