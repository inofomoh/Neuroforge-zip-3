
# NeuroForge Engine 2025

The most powerful mobile + PC open-world game engine.
Supports full 3D, AI, mission system, NPL (Natural Programming Language),
procedural generation, monetization, and full export.

## Features
- Procedural World & Terrain Generation
- NPC AI, Combat, and Temporal Memory
- Natural Language Game Creation
- Neural Graphics Generator
- Vehicle System + Missions + Inventory
- Full Mobile & PC Compatibility
- Runs on GitHub Codespaces & Pydroid 3
- Full Export + Monetization

## Usage
Run `main.py` to launch the engine.
Edit and extend modules in the `engine/` folder to add your own systems.
