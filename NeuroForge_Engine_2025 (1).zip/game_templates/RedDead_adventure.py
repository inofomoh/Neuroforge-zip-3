# Red Dead-style adventure game template
