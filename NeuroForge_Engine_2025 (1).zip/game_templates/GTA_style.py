# GTA-style open world template
