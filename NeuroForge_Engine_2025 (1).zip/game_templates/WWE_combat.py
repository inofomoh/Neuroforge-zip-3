# WWE-style combat game template
